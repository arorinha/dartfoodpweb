require("../models/user");
const mongoose = require("mongoose");
const User = mongoose.model("users");

const salvar = (req, res) => {
  const user = new User(req.body);
  user
    .save()
    .then(() => {
      return res.status(200).json({ message: "usuario salvo." });
    })
    .catch((erro) => {
      return res
        .status(500)
        .json({ message: "não foi possível salvar usuário." });
    });
};

const autenticar = (req, res) => {
  User.findOne({
    username: req.body.username,
    password: req.body.password,
  })
    .then((user) => {
      if (user != null) {
        return res.status(200).json({ autenticacao: true });
      } else {
        return res.status(404).json({ autenticacao: false });
      }
    })
    .catch((erro) => {
      return res.json({ erro: erro });
    });
};

const listar = (req, res) => {
  User.find()
    .then((users) => {
      return res.status(200).json(users);
    })
    .catch((erro) => {
      return res.status(404).json(erro);
    });
};

module.exports = { salvar, autenticar, listar };
