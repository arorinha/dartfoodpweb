const { urlencoded } = require("express");
const express = require("express");
const app = express();
const mongoose = require("mongoose");
const user = require("./routes/user");
const pizza = require("./routes/pizza");
const pao = require("./routes/pao");
const dotenv = require("dotenv").config();

app.use(express.json());
app.use(urlencoded({ extended: true }));

mongoose.Promise = global.Promise;
mongoose
  .connect(process.env.LINK_BANCO)
  .then(() => {
    console.log("connectado");
  })
  .catch((erro) => {
    console.log(erro);
  });

app.use("/user", user);
app.use("/pizza", pizza);
app.use("/pao", pao);

app.listen(3000, () => {
  console.log("rodando!");
});
