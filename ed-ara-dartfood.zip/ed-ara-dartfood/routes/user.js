const express = require("express");
const app = express();
const { autenticar, listar, salvar } = require("../controllers/user");

app.get("/listar", listar);
app.post("/autenticar", autenticar);
app.post("/salvar", salvar);

module.exports = app;
