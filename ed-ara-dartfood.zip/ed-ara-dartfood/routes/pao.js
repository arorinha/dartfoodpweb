const express = require("express");
const app = express();
const { listar } = require("../controllers/pao");

app.get("/listar", listar);

module.exports = app;
