const mongoose = require("mongoose");

const User = new mongoose.Schema({
  username: {
    type: String,
    require: true,
  },
  password: {
    type: String,
    require: true,
  },
});

mongoose.model("users", User);
