require("../models/pizza");
const mongoose = require("mongoose");
const Pizza = mongoose.model("pizzas");

const listar = (req, res) => {
  Pizza.find()
    .then((pizzas) => {
      return res.status(200).json(pizzas);
    })
    .catch((erro) => {
      return res.status(404).json(erro);
    });
};

module.exports = { listar };
