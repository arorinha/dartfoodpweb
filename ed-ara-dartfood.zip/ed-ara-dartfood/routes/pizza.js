const express = require("express");
const app = express();
const { listar } = require("../controllers/pizza");

app.get("/listar", listar);

module.exports = app;
