require("../models/pao");
const mongoose = require("mongoose");
const Pizza = mongoose.model("paes");

const listar = (req, res) => {
  Pao.find()
    .then((paes) => {
      return res.status(200).json(paes);
    })
    .catch((erro) => {
      return res.status(404).json(erro);
    });
};

module.exports = { listar };
