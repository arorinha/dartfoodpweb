const mongoose = require("mongoose");

const Pao = new mongoose.Schema({
  valor: {
    type: mongoose.Schema.Types.Number,
    require: true,
  },
  restaurante: {
    type: String,
    require: true,
  },
  imagem: {
    type: String,
    require: true,
  },
  titulo: {
    type: String,
    require: true,
  },
});

mongoose.model("paes", Pao);
